# Credits
MiniVHD Copyright (c) 2019 Sherman Perry

MiniVHD was made possible with the help of the following projects

### libxml2
**Project Home:** http://www.xmlsoft.org/
**License:** MIT (see src/libxml2_encoding.c for details)

### cwalk
**Project Home:** https://likle.github.io/cwalk/
**Licence:** MIT (https://github.com/likle/cwalk/blob/master/LICENSE.md)
