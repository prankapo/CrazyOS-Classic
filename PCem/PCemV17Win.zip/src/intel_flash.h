extern device_t intel_flash_bxt_ami_device;
extern device_t intel_flash_bxt_device;
extern device_t intel_flash_bxb_device;
extern device_t intel_flash_28fb200bxt_device;
extern device_t intel_flash_28f002bc_device;
