void scamp_init(void);
