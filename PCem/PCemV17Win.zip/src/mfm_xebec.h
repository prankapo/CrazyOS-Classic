extern device_t mfm_xebec_device;
extern device_t dtc_5150x_device;
