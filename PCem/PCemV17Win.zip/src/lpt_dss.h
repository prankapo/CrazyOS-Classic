extern lpt_device_t dss_device;
