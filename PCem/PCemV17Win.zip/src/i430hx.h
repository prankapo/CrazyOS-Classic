void i430hx_init();
void i430hx_reset();
