extern device_t adgold_device;
