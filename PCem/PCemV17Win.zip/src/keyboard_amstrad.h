void keyboard_amstrad_init();
void keyboard_amstrad_reset();
void keyboard_amstrad_poll();
