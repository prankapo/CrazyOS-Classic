extern mouse_t mouse_ps2_2_button;
extern mouse_t mouse_intellimouse;
