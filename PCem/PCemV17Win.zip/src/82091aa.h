void aip_82091aa_init(uint16_t base);
