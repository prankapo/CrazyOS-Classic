void ps1mb_init();
void ps1mb_m2121_init();
void ps1mb_m2133_init(void);
