extern device_t scsi_aha1542c_device;
extern device_t scsi_bt545s_device;
