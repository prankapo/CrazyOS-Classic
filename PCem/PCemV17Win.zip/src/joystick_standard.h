extern joystick_if_t joystick_standard;
extern joystick_if_t joystick_standard_4button;
extern joystick_if_t joystick_standard_6button;
extern joystick_if_t joystick_standard_8button;
