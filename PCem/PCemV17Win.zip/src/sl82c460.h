void sl82c460_init();
